﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RecordStore.Models
{
    public class GenreDetailModel
    {
        public Genre Genre { get; set; }
        public string LinkText { get; set; }
    }
}