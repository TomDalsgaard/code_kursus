﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_Csharp_AdvancedCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            //int opt, num1, num2;
            int opt;
            double num1, num2;
            double result;

            while (true) // hvis vi ønsker at gentage processen
            {


                int[] optArr = new int[4] { 1, 2, 3, 4 };

                //label:
                Console.WriteLine("\nMENU\n");
                Console.WriteLine("Press 1 for add");
                Console.WriteLine("Press 2 for subtraction");
                Console.WriteLine("Press 3 for multiplication");
                Console.WriteLine("Press 4 for division");

                Console.Write("\nEnter your option:\t");

                


                // opt = Convert.ToInt32(Console.ReadLine());

                while (!int.TryParse(Console.ReadLine(), out opt))
                {
                    Console.Write("\nEnter your option as number:\t");

                    if (optArr.Contains(opt))
                    {
                        break;
                    }

                }

                while (!optArr.Contains(opt))
                {
                    Console.Write("\nEnter your new option:\t");

                    //while (!int.TryParse(Console.ReadLine(), out opt))
                    //{
                    //    Console.Write("\nEnter your option as number:\t");
                    //}

                }

                if (opt == 5) break;


                Console.Write("\n\nEnter first number:\t");
                while (!double.TryParse(Console.ReadLine(), out num1))
                {
                    Console.Write("\n\nEnter first number:\t");
                }


                Console.Write("Enter second number:\t");
                num2 = Convert.ToInt32(Console.ReadLine());

                if (opt == 1)
                {
                    result = num1 + num2;
                    Console.WriteLine("\n{0} + {1} = {2}", num1, num2, result);
                }
                else if (opt == 2)
                {
                    result = num1 - num2;
                    Console.WriteLine("\n{0} - {1} = {2}", num1, num2, result);
                }
                else if (opt == 3)
                {
                    result = num1 * num2;
                    Console.WriteLine("\n{0} x {1} = {2}", num1, num2, result);
                }
                else if (opt == 4)
                {
                    result = num1 / num2;
                    Console.WriteLine("\n{0} / {1} = {2:F3}", num1, num2, result);
                }
                else
                {
                    Console.WriteLine("Invalid option. Try again");
                    //goto label;
                    break;
                }
                Console.ReadLine();
            }



        }

    }
}


