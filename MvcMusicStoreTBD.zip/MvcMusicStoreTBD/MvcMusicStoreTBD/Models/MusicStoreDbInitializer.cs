﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcMusicStoreTBD.Models
{
    public class MusicStoreDbInitializer : System.Data.Entity.DropCreateDatabaseAlways<MusicStoreDBContext>
    {
        protected override void Seed(MusicStoreDBContext context)
        {
            context.Artists.Add(new Artist { Name = "Al Di Meola" });
            context.Genres.Add(new Genre { Name = "Jazz" });
            context.Albums.Add(new Album
            {
                Artist = new Artist { Name = "Rush" },
                Genre = new Genre { Name = "Rock" },
                Price = 9.99m,
                Title = "Caravan"
            });

            context.Artists.Add(new Models.Artist { Name = "Gasolin" });
            context.Artists.Add(new Models.Artist { Name = "Bach" });
            context.Genres.Add(new Genre { Name = "Folk Rock" });
            context.Albums.Add(new Album
            {
                Title= "Moonlight sonate",
                Artist= new Artist { Name="Bethoven"},
                Genre= new Genre { Name="Classic"},
                Price = 7.95m
            });

            base.Seed(context);
        }
    }
}