﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountingApp
{
    public class Journal
    {
        List<float> entries;

        public Journal()
        {
            entries = new List<float>();
        }

        public void AddEntry(float entry)
        {
            entries.Add(entry);
        }

        public EntriesStatistics ComputeStatistice()
        {
            EntriesStatistics stats = new EntriesStatistics();
            float sum = 0;

            foreach (var entry in entries)
            {
                stats.HigehstEntries = Math.Max(entry, stats.HigehstEntries);
                stats.LowestEntries = Math.Min(entry, stats.LowestEntries);
                sum += entry;
            }
            stats.AverageEntries = sum / entries.Count;

            return stats;
        }
    }
}
