﻿namespace AccountingApp
{
    public class EntriesStatistics
    {

        public EntriesStatistics()
        {
            HigehstEntries = 0;
            LowestEntries = float.MaxValue;
        }

        public float AverageEntries;
        public float HigehstEntries;
        public float LowestEntries;
    }
}