﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountingApp
{
    class Program
    {
        static void Main(string[] args)
        {

            var journal = new Journal();
            journal.AddEntry(45);
            journal.AddEntry(89.67f);
            journal.AddEntry(50.67f);
            journal.AddEntry(78.67f);

            var stats = journal.ComputeStatistice();

            Console.WriteLine(stats.AverageEntries);
            Console.WriteLine(stats.HigehstEntries);
            Console.WriteLine(stats.LowestEntries);
        }


    }

    
}
