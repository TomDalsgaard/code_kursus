﻿namespace Carfleet
{
    public class FleetStats
    {
        public FleetStats()
        {
            Highest = double.MinValue;
            Lowest = double.MaxValue;
        }

        public double Average;
        public double Highest;
        public double Lowest;
    }
}
