﻿
namespace Carfleet
{
    public class Car
    {
        private string _make;
        private string _model;
        private int _year;
        private double _currentValue;

        public Car(string make, string model, int year, double currentValue)
        {
            _make = make;
            _model = model;
            _year = year;
            _currentValue = currentValue;
        }

        public double GetCurrentValue()
        {
            return _currentValue;
        }

        public int GetYear()
        {
            return _year;
        }
        
        public override string ToString()
        {
            return string.Format(
                " Make {0} \n Model {1} \n Year {2}\n Current Value {3}\n ", 
                _make, _model, _year,_currentValue);
        }

    }
}
