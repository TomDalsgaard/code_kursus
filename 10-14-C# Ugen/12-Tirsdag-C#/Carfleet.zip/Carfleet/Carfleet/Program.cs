﻿using System;
namespace Carfleet
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new Car("Oldsmobile", "442", 1970, 90000);
            Car car2 = new Car("Alfa Romeo", "Montreal", 1977, 110000);
            Car car3 = new Car("Alvis", "Crested Eagle", 1940, 67000);


            Fleet fleet = new Fleet();
            fleet.Cars.Add(car1);
            fleet.Cars.Add(car2);
            fleet.Cars.Add(car3);

            Console.WriteLine("Fleet value: "+fleet.GetFleetValue());

            var stats = fleet.GetStats();
            Console.WriteLine("Average: " + stats.Average);
            Console.WriteLine("Highest: " + stats.Highest);
            Console.WriteLine("Lowest: " + stats.Lowest);



            Console.WriteLine("Cars of the Year \n");
            foreach (var car in fleet.GetCarsOfYear(1970))
            {
                Console.WriteLine(car);
            }

            Console.WriteLine("Car list \n");
            foreach (var car in fleet.Cars)
            {
                Console.WriteLine(car);
            }

            Console.ReadKey();
        }
    }
}
