﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Carfleet
{
    public class Fleet 
    {
        public List<Car> Cars;
        public Fleet()
        {
            Cars = new List<Car>();
        }

        public FleetStats GetStats()
        {
            FleetStats stats = new FleetStats();
            double sum = 0;
            foreach (var car in Cars)
            {
                double value = car.GetCurrentValue();
                stats.Highest = Math.Max(value, stats.Highest);
                stats.Lowest = Math.Min(value, stats.Lowest);
                sum += value;
            }
            stats.Average = sum / Cars.Count;

            return stats;
        }

        public double GetFleetValue()
        {
            return Cars.Sum(car => car.GetCurrentValue());
        }

        public List<Car> GetCarsOfYear(int year)
        {
            return Cars.FindAll(car => car.GetYear() == year);
        }
    }
}
