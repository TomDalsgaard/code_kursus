﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DyrPro
{
    public class Hund : Dyr
    {



        public Hund(int øjne, int ben, string navn) :base(øjne,ben)
        {
            Navn = navn;
        }


        private string navn;
        public string Navn
        {
            get { return navn; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    navn = value;
                }
            }
        }
    }
}
