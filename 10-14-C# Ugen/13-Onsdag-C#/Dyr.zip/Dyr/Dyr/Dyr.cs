﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DyrPro
{
    public class Dyr
    {


        public Dyr(int øjne, int ben)
        {
            Ben = ben;
            this.øjne = øjne;
        }

   

        private int øjne;
        public int Øjne
        {
            get { return øjne; }
            set { øjne = value; }
        }
        
        public int Ben { get; set; }

    }
}
