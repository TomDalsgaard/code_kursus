﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DyrPro
{
    public class Kat : Dyr
    {
        public void FangMus()
        {
            
        }
    }
}
