'use strict'
// http://bit.ly/ObjAndProto

var Person = function(name, age) {
  var _name,
    _age
  this.getName = function() {
    return _name;
  }
  this.setName = function(value) {
    if (value != "Jens")
      _name = value;
  }
  this.getAge = function() {
    return _age;
  }
  this.setAge = function(value) {
    if (value > 0 && value < 130)
      _age = value;
  }
  this.Lastname = "";
  //_name = name;
  this.setName(name);
  this.setAge(age);
}

Person.prototype = {
  toString: function(){
    return this.getName() + ' is ' + this.getAge();
  }
}

var hans = new Person("Hans", 56);
var jens = new Person("Jes", 28);

hans.setName('Jens');
hans.setAge(34);
hans.Lastname = 'Nielsen';

//Person.prototype.toString = function(){
//    return this.getName() + ' is ' + this.getAge();
//}

//display(hans);
display(hans.getName() + ' ' + hans.Lastname + ' ' + hans.getAge());
display(jens.getName() + ' ' + jens.getAge());
display(hans.toString());
